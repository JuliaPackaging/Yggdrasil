..
   ----------------------------------------------------------------
   SUNDIALS Copyright Start
   Copyright (c) 2002-2025, Lawrence Livermore National Security
   and Southern Methodist University.
   All rights reserved.

   See the top-level LICENSE and NOTICE files for details.

   SPDX-License-Identifier: BSD-3-Clause
   SUNDIALS Copyright End
   ----------------------------------------------------------------

.. include:: ../../../arkode/guide/source/sunmatrix/ARKODE_requirements.rst
.. include:: ../../../cvode/guide/source/sunmatrix/CVODE_requirements.rst
.. include:: ../../../cvodes/guide/source/sunmatrix/CVODES_requirements.rst
.. include:: ../../../ida/guide/source/sunmatrix/IDA_requirements.rst
.. include:: ../../../idas/guide/source/sunmatrix/IDAS_requirements.rst
.. include:: ../../../kinsol/guide/source/sunmatrix/KINSOL_requirements.rst