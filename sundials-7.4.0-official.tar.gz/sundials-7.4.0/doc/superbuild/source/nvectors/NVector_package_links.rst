..
   ----------------------------------------------------------------
   SUNDIALS Copyright Start
   Copyright (c) 2002-2025, Lawrence Livermore National Security
   and Southern Methodist University.
   All rights reserved.

   See the top-level LICENSE and NOTICE files for details.

   SPDX-License-Identifier: BSD-3-Clause
   SUNDIALS Copyright End
   ----------------------------------------------------------------

.. include:: ../../../arkode/guide/source/nvectors/ARKODE_requirements.rst
.. include:: ../../../cvode/guide/source/nvectors/CVODE_requirements.rst
.. include:: ../../../cvodes/guide/source/nvectors/CVODES_requirements.rst
.. include:: ../../../ida/guide/source/nvectors/IDA_requirements.rst
.. include:: ../../../idas/guide/source/nvectors/IDAS_requirements.rst
.. include:: ../../../kinsol/guide/source/nvectors/KINSOL_requirements.rst